//
//  UIImage+Compression.h
//  MySweep
//
//  Created by wei liu on 16/8/23.
//  Copyright © 2016年 wei liu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Compression)

+ (UIImage *)imageWithImage:(UIImage*)image
               scaledToSize:(CGSize)newSize;

@end
