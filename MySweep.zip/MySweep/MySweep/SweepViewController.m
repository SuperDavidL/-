//
//  SweepViewController.m
//  MySweep
//
//  Created by wei liu on 16/8/22.
//  Copyright © 2016年 wei liu. All rights reserved.
//

#import "SweepViewController.h"
#import "UIButton+GetMyBtn.h"
#import "UIView+Frame.h"
#import "CustomView.h"
#import "UIImage+FixOrientation.h"
#import "UIImage+Compression.h"
#import <AVFoundation/AVFoundation.h>
#import <AssetsLibrary/AssetsLibrary.h>
#import <Photos/Photos.h>
#import <MobileCoreServices/MobileCoreServices.h>
#define ScreenHeight [UIScreen mainScreen].bounds.size.height
#define ScreenWidth  [UIScreen mainScreen].bounds.size.width
#define MiddleRect  CGRectMake(60, (ScreenHeight - (ScreenWidth-60*2))/2 , (ScreenWidth-60*2), (ScreenWidth-60*2))

@interface SweepViewController ()<AVCaptureMetadataOutputObjectsDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
    AVCaptureSession *session;
}
@property(nonatomic,strong) CustomView *middleView;
@property(nonatomic,strong) AVCaptureMetadataOutput * output;
@property(nonatomic,strong)  AVCaptureDeviceInput * input;
@property(nonatomic,strong) AVCaptureVideoPreviewLayer * AVCaptureLayer;
@property(nonatomic,strong) UIImagePickerController *imagePickerComtrller;
@property(nonatomic,strong) CIDetector *detector;

@end

@implementation SweepViewController

-(void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    _AVCaptureLayer = nil;
    _output = nil;
    session = nil;
    _detector = nil;
}

//创建探测器
- (CIDetector *)detector
{
    if (_detector == nil) {
        _detector =  [CIDetector detectorOfType:CIDetectorTypeQRCode context:nil options:@{CIDetectorAccuracy: CIDetectorAccuracyHigh}];
    }
    return _detector;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    UIButton *btn = [UIButton creatANewButtonTitle:@"相册" andSel:@selector(showPicture) andViewController:self];
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithCustomView:btn];
    self.navigationItem.rightBarButtonItem = item;
    self.view.backgroundColor = [UIColor brownColor];
    [self creatBack];
    [self AddCustomView];
    [self creatSeccsion];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(avCaptureInputPortFormatDescriptionDidChangeNotification:) name:AVCaptureInputPortFormatDescriptionDidChangeNotification object:nil];
}

- (void)avCaptureInputPortFormatDescriptionDidChangeNotification:(NSNotification *)userInfo
{
    _output.rectOfInterest = [_AVCaptureLayer metadataOutputRectOfInterestForRect:CGRectMake(_middleView.x - 20, _middleView.y-20, _middleView.width+40, _middleView.height+40)];
}

- (void)creatBack
{
    UIView *maskView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight )];
    maskView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.6];
    [self.view addSubview:maskView];
    UIBezierPath *rectPath = [UIBezierPath bezierPathWithRect:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
    //    [rectPath appendPath:[[UIBezierPath bezierPathWithRect:CM((SCREEN_WIDTH - 250) / 2, 66, 250, 250)] bezierPathByReversingPath]];
    [rectPath appendPath:[[UIBezierPath bezierPathWithRoundedRect:MiddleRect cornerRadius:1] bezierPathByReversingPath]];
    CAShapeLayer *shapeLayer = [CAShapeLayer layer];
    shapeLayer.path = rectPath.CGPath;
    maskView.layer.mask = shapeLayer;
    
}

- (void)AddCustomView
{
    _middleView = [[CustomView alloc] initWithFrame:MiddleRect];
    [self.view addSubview:_middleView];
}

- (void)creatSeccsion
{
    // Do any additional setup after loading the view, typically from a nib.
    //获取摄像设备
    AVCaptureDevice * device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    //创建输入流
    _input = [AVCaptureDeviceInput deviceInputWithDevice:device error:nil];
    //创建输出流
    _output = [[AVCaptureMetadataOutput alloc]init];
    //设置代理 在主线程里刷新
    [_output setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
    //初始化链接对象
    session = [[AVCaptureSession alloc]init];
    //高质量采集率 (没必要这么高 AVCaptureSessionPresetHigh)
    [session setSessionPreset:AVCaptureSessionPreset640x480];
    if ([session canAddInput:_input]) {
        [session addInput:_input];
    }
    if ([session canAddOutput:_output]) {
        [session addOutput:_output];
    }
    //设置扫码支持的编码格式(如下设置条形码和二维码兼容)
    _output.metadataObjectTypes=@[AVMetadataObjectTypeQRCode,AVMetadataObjectTypeEAN13Code, AVMetadataObjectTypeEAN8Code, AVMetadataObjectTypeCode128Code];
    _AVCaptureLayer = [AVCaptureVideoPreviewLayer layerWithSession:session];
    _AVCaptureLayer.videoGravity=AVLayerVideoGravityResizeAspectFill;
    _AVCaptureLayer.frame=self.view.bounds;
    [self.view.layer insertSublayer:_AVCaptureLayer atIndex:0];
    //开始捕获
    [session startRunning];
}

-(void)captureOutput:(AVCaptureOutput *)captureOutput didOutputMetadataObjects:(NSArray *)metadataObjects fromConnection:(AVCaptureConnection *)connection{
    if (metadataObjects.count>0) {
#warning 扫一扫识别的二维码会在这里产生回调
        [self playBeep];
        [session stopRunning];
        [_middleView StopAnimation];
        AVMetadataMachineReadableCodeObject * metadataObject = [metadataObjects objectAtIndex : 0 ];
        //输出扫描字符串
        [self showAleartAndMessage:metadataObject.stringValue];
    }else{
        [self showAleartAndMessage:@"未发现二维码"];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)showPicture
{
    PHAuthorizationStatus status = [PHPhotoLibrary authorizationStatus];
    switch (status) {
        case PHAuthorizationStatusNotDetermined :
            [self judgeUserPermissions];
            break;
        case PHAuthorizationStatusRestricted :
        {
            [self showAleartAndMessage:@"没有访问相册的权限，可能是由于家长控制功能" ];
        }
            break;
        case PHAuthorizationStatusDenied :
        {
            [self showAleartAndMessage:@"没有访问相册的权限，可能是由于家长控制功能" ];
        }
            break;
        case PHAuthorizationStatusAuthorized :
            [self CreatImagePicker];
            break;
            
        default:
            break;
    }
}

- (void)judgeUserPermissions
{
    [AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo completionHandler:^(BOOL granted) {
        if (granted) {
            [self CreatImagePicker];
        }else{
            [self showAleartAndMessage:@"未授权，想体验更多功能，可在设置中打开权限"];
        }
    }];
}

- (void)CreatImagePicker
{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    picker.mediaTypes = @[(NSString*)kUTTypeImage];
    picker.allowsEditing = NO;
    picker.delegate = self;
    [self presentViewController:picker animated:YES completion:^{}];
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info
{
    UIImage* image = [info objectForKey:UIImagePickerControllerOriginalImage];
    //防止图片旋转
    image = [image fixOrientation];
    //图片太大，进行剪切
    UIImage *compressionImage;
    if (image.size.height >=640 || image.size.width >= 640) {
        CGFloat bili = image.size.height/image.size.width;
        int a = 640*bili;
        int b = 640/bili;
        if (bili > 1) {
            compressionImage  =[UIImage imageWithImage:image scaledToSize:CGSizeMake(b,640) ];
        }else{
            compressionImage =[UIImage imageWithImage:image scaledToSize:CGSizeMake(640,a)];
        }
    }else{
        compressionImage = image;
    }
    
    CIImage *ciImage = [CIImage imageWithCGImage:compressionImage.CGImage];
    //创建探测器
      NSArray *features = [self.detector featuresInImage:ciImage];
    if (features.count>0) {
#warning 发现图片中的二维码会在这里产生回调
        NSString * content;
        for (CIQRCodeFeature *result in features) {
            [self playBeep];
             content = result.messageString;
        }
        [picker dismissViewControllerAnimated:YES completion:^{
            [self showAleartAndMessage:content];
        }];
    }else{
        [picker dismissViewControllerAnimated:YES completion:^{
            [self showAleartAndMessage:@"未发现二维码"];
        }];
    }

}

- (void)playBeep{
    SystemSoundID soundID;
    soundID = kSystemSoundID_Vibrate;//震动
    AudioServicesPlaySystemSound(soundID);
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [picker dismissViewControllerAnimated:YES completion:^{}];
}

- (void)showAleartAndMessage:(NSString *)message
{
    UIAlertController *aleartControl = [UIAlertController alertControllerWithTitle:@"提示" message:message preferredStyle:UIAlertControllerStyleAlert];
    [aleartControl addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        [session startRunning];
        [_middleView StartAnimation];
    }]];
    [self presentViewController:aleartControl animated:YES completion:nil];

}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
