//
//  UIButton+GetMyBtn.m
//  MySweep
//
//  Created by wei liu on 16/8/22.
//  Copyright © 2016年 wei liu. All rights reserved.
//

#import "UIButton+GetMyBtn.h"

@implementation UIButton (GetMyBtn)
+ (UIButton *)creatANewButtonTitle:(NSString *)title andSel:(SEL)sel andViewController:(UIViewController *)view
{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(0, 0, 50, 44);
    [btn setTitle:title forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [btn addTarget:view action:sel forControlEvents:UIControlEventTouchUpInside];
    return btn;
}
@end
