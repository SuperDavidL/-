//
//  CustomView.m
//  MySweep
//
//  Created by wei liu on 16/8/22.
//  Copyright © 2016年 wei liu. All rights reserved.
//

#import "CustomView.h"
#import "UIView+Frame.h"
#define CornerLength 20
#define CornerWidth   6
#define LineWidth   0.5
#define AnimationKey @"LineMoving"


@interface CustomView ()

@property (nonatomic,strong)UIView *MiddleLineView;

@end

@implementation CustomView

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor clearColor];
        [self CreatMiddleLine];
        [self StartAnimation];
    }
    return self;
}


- (void)CreatMiddleLine
{
    _MiddleLineView = [[UIView alloc] initWithFrame:CGRectMake(0, 10, self.width, 10)];
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, _MiddleLineView.width, _MiddleLineView.height)];
    UIImage *lineImage = [UIImage imageNamed:@"QRCodeLine"];
    lineImage = [lineImage imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    imageView.tintColor = [UIColor greenColor];
    imageView.image = lineImage;
    imageView.contentMode = UIViewContentModeScaleAspectFill;
    [_MiddleLineView addSubview:imageView];
    [self addSubview:_MiddleLineView];
}

- (void)StartAnimation
{
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"transform.translation.y"];
    animation.duration = 3;
    animation.fromValue = [NSNumber numberWithInteger:10];
    animation.toValue = [NSNumber numberWithFloat:self.height-30];
    animation.repeatCount = CGFLOAT_MAX;
    [_MiddleLineView.layer addAnimation:animation forKey:AnimationKey];
}

- (void)StopAnimation
{
    [_MiddleLineView.layer removeAnimationForKey:AnimationKey];
}

-(void)drawRect:(CGRect)rect
{
    
    for (int i = 0; i < 4; i ++) {
        UIBezierPath* bezierPath = [UIBezierPath bezierPath];
        UIBezierPath *topLinePath = [UIBezierPath bezierPath];

        switch (i) {
            case 0:
                [bezierPath moveToPoint: CGPointMake(0, CornerLength)];
                [bezierPath addLineToPoint: CGPointMake(0, 0)];
                [bezierPath addLineToPoint: CGPointMake(CornerLength, 0)];
                [topLinePath moveToPoint:CGPointMake(CornerLength, 0)];
                [topLinePath addLineToPoint:CGPointMake(self.width-CornerLength, 0)];
                break;
            case 1:
                [bezierPath moveToPoint: CGPointMake(self.width-CornerLength, 0)];
                [bezierPath addLineToPoint: CGPointMake(self.width, 0)];
                [bezierPath addLineToPoint: CGPointMake(self.width, CornerLength)];
                [topLinePath moveToPoint:CGPointMake(self.width , CornerLength)];
                [topLinePath addLineToPoint:CGPointMake(self.width, self.height-CornerLength)];

                break;
            case 2:
                [bezierPath moveToPoint: CGPointMake(0, self.height-CornerLength)];
                [bezierPath addLineToPoint: CGPointMake(0, self.height)];
                [bezierPath addLineToPoint: CGPointMake(CornerLength, self.height)];
                [topLinePath moveToPoint:CGPointMake(CornerLength, self.height)];
                [topLinePath addLineToPoint:CGPointMake(self.width-CornerLength, self.height)];

                break;

            case 3:
                [bezierPath moveToPoint: CGPointMake(self.width-CornerLength, self.height)];
                [bezierPath addLineToPoint: CGPointMake(self.width, self.height)];
                [bezierPath addLineToPoint: CGPointMake(self.width, self.height-CornerLength)];
                [topLinePath moveToPoint:CGPointMake(0, 20)];
                [topLinePath addLineToPoint:CGPointMake(0, self.height-CornerLength)];
                break;
            default:
                break;
        }
        [UIColor.greenColor setStroke];
        bezierPath.lineWidth = CornerWidth;
        [bezierPath stroke];
        [[UIColor whiteColor] setStroke];
        topLinePath.lineWidth = LineWidth;
        [topLinePath stroke];
    }
    
}




@end
