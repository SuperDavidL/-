//
//  ViewController.m
//  MySweep
//
//  Created by wei liu on 16/8/22.
//  Copyright © 2016年 wei liu. All rights reserved.
//

#import "ViewController.h"
#import "SweepViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(100, 100, 100, 40);
    btn.center = self.view.center;
    btn.backgroundColor = [UIColor blackColor];
    [btn setTitle:@"Sweep" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(push) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
}

- (void)push{
    SweepViewController *sweep = [[SweepViewController alloc] init];
    [self.navigationController pushViewController:sweep animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
