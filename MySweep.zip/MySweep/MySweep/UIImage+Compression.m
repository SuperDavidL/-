//
//  UIImage+Compression.m
//  MySweep
//
//  Created by wei liu on 16/8/23.
//  Copyright © 2016年 wei liu. All rights reserved.
//

#import "UIImage+Compression.h"

@implementation UIImage (Compression)

//压缩图片
+ (UIImage *)imageWithImage:(UIImage*)image
              scaledToSize:(CGSize)newSize
{
    UIGraphicsBeginImageContext(newSize);
    [image drawInRect:CGRectMake(0,0,newSize.width,newSize.height)];
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}

@end
